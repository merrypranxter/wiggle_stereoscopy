// Toggle timing and crossfade curves
