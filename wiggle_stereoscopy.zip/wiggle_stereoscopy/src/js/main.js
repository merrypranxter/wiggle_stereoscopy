// Wiggle stereoscopy renderer
