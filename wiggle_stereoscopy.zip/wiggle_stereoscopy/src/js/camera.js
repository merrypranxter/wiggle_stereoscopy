// Dual camera setup and baseline control
