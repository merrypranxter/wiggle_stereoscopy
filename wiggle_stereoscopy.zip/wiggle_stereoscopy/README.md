# wiggle_stereoscopy

> two frames. wiggle. depth.

Wiggle stereoscopy system — two frames from slightly different viewpoints toggle rapidly to create depth from motion parallax. No glasses required. The effect is surprisingly robust and works with any rendered scene. Parameterize camera baseline, toggle speed, and crossfade curve.

## Live Controls

| Key | Action |
|-----|--------|
| `Space` | Toggle wiggle on/off |
| `↑ / ↓` | Increase / decrease toggle speed |
| `← / →` | Decrease / increase camera baseline |
| `C` | Toggle crossfade vs hard cut |
| `F` | Freeze on left view |
| `G` | Freeze on right view |

## Named Regimes

- **Natural Stereo** — 6.5 cm baseline (human IPD)
- **Hyperstereo** — 30 cm baseline, exaggerated depth
- **Hypostereo** — 2 cm baseline, subtle depth
- **Slow Wiggle** — 2 Hz, visible flicker but clear parallax
- **Fast Wiggle** — 15 Hz, smooth but weaker depth
- **Crossfade** — Soft dissolve between views

## The Math

Motion parallax depth:
- Displacement Δx = baseline · f / z
- Where f = focal length, z = depth
- Larger baseline → larger displacement → stronger depth
- Smaller z (closer) → larger displacement

Toggle timing:
- Frame A: camera at -baseline/2
- Frame B: camera at +baseline/2
- Toggle frequency: 5–15 Hz (period = 200–66 ms)
- Crossfade: mix = 0.5 + 0.5 · sin(2π · t · freq)

## Acknowledgments

Wiggle 3D tradition, motion parallax research, modern implementations by Jim Gasperini and others.
