# Visual Targets: wiggle_stereoscopy

> TODO: describe desired visual output, color palettes, and animation behavior.
