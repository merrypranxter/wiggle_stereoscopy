# Math Reference: wiggle_stereoscopy

> TODO: add mathematical foundations, equations, and reference values.
